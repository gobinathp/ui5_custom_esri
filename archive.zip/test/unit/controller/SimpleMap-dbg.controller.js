/*global QUnit*/

sap.ui.define([
	"esricustom/controller/SimpleMap.controller"
], function (Controller) {
	"use strict";

	QUnit.module("SimpleMap Controller");

	QUnit.test("I should test the SimpleMap controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});
