sap.ui.define([
	"esricustom/test/unit/controller/SimpleMap.controller"
], function () {
	"use strict";
});
