jQuery.sap.registerModulePath('arcgis_server', "https://js.arcgis.com");
sap.ui.define([
	'arcgis_server/4.20/init'
], function () {
	jQuery.sap.includeStyleSheet(jQuery.sap.getResourcePath("ArcGis") + '/library.css');
	sap.ui.getCore().initLibrary({
		name: "ArcGis",
		dependencies: ["sap.ui.core"],
		types: [],
		interfaces: [],
		controls: [
			"esricustom.ArcGis.Map"
		],
		elements: [],
		noLibraryCSS: true,
		version: "0.0.1"
	});
	return {
		require: require
	};
	return ArcGis;
});