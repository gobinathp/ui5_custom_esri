/* global QUnit */

sap.ui.require(["esricustom/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
