sap.ui.define([
	"sap/ui/core/Control",
	"sap/ui/core/ResizeHandler",
	"esricustom/ArcGis/esri",
	"sap/m/Button"
], function (Control, ResizeHandler, esri, Button) {

	"use strict";

	return Control.extend("esricustom.ArcGis.Map", {
		mapLoad: function () {
			jQuery.sap.includeStyleSheet("https://js.arcgis.com/4.22/esri/themes/light/main.css");
			require([
				"esri/config",
				"esri/Map",
				"esri/views/MapView",
				"esri/widgets/Locate",
				"esri/widgets/Search"

			], function (
				esriConfig,
				Map,
				MapView,
				Locate,
				Search
			) {

				const map = new Map({
					basemap: "gray-vector"
				});

				const view = new MapView({
					map: map,
					container: "__map0",
					zoom: 6,
					center: {
						latitude: 11.1271,
						longitude: 78.6569
					}
				});

				const locate = new Locate({ //Location Function
					view: view,
					useHeadingEnabled: false,
					goToOverride: function (view, options) {
						options.target.scale = 1500;
						return view.goTo(options.target);
					}
				});
				view.ui.add(locate, "top-left"); // End Of Location Function

				const search = new Search({ // Start of Location Search
					view: view
				});

				view.ui.add(search, "top-right"); // End Of Location Search
			});
		},

		metadata: {
			properties: {
				width: {
					type: "sap.ui.core.CSSSize",
					defaultValue: "100%"
				},
				height: {
					type: "sap.ui.core.CSSSize",
					defaultValue: "100%"
				},
				Class: { //this allows the developer to also apply their own style classes 
					type: "string",
					defaultValue: ""
				}
			},
			aggregations: {
				content: {
					type: "sap.ui.core.Control"
				}
			}
		},

		renderer: function (oRm, oControl) { // the part creating the HTML
			oRm.write("<div style='height:100%;width:100%;' ");
			oRm.writeControlData(oControl);  // writes the Control ID and enables event handling - important!
			oRm.write(">");
			oRm.renderControl(oControl._html);
			oRm.write("</div>");
		},

		init: function () {
			this._html = new sap.ui.core.HTML({ content: "<div style='height:100%;width:100%;' id='" + this.getId() + "-map'></div>" })
		},

		onAfterRendering: function () {
			if (!this.initialized) {
				this.initialized = true;
				this.mapLoad();
			}
		}

	});
});